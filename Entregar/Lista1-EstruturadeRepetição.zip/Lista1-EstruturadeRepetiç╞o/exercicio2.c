#include <stdio.h>
int main(void)
{
    int i = 0, qtd = 0;
    float media;
    for (i = 199; i > 100; i--)
    {

        if (i % 3 == 0)
        {
            printf("%d\t", i);
        }
    }
    return 0;
}