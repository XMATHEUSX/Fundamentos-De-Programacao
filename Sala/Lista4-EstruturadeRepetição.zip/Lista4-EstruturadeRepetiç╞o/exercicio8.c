#include <stdio.h>
int main(void)
{
    int num = 0;
    for (num = 0; num <= 100; num = num + 1)
    {
        printf("%d\n", num);
    }
    return 0;
}
// a estrutura de repetição for 

// o programa imprime na tela os numero inteiros de 0 a 100