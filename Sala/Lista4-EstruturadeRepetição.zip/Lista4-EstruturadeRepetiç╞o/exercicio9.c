#include <stdio.h>
int main(void)
{
    int num = 0;
    do
    {
        num = num + 1;
        printf("%d\n", num);
 // } while (num <= 100);
    } while (num < 100);
    return 0;
}
// a estrutura de repetição do while 

// o programa imprime na tela os numero inteiros de 0 a 101

//somente é necessario substituir p <= por < o 