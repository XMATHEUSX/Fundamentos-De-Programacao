#include <stdio.h>
int main(void)
{
    int i = 0;
    for (i = 21; i < 35; i++)
    {
        printf("%d\t", i);
    }
    return 0;
}